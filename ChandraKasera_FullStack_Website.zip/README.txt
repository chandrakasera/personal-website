Run Instructions:

1. Install dependencies
2. Run backend: flask run
3. Run frontend: npm start